var JokerShieldOn = 0;
var NowJ1Go = 1;

function GiveShield() {
  if (possession == 1)
  { Bar1Shield();}

  if (possession == 2)
  {Bar2Shield();}
};

function JokerShieldMovement() {

if (JokerShieldOn == 1) {
    if (NowJ1Go == 1)
    {
      Joker1Goup();
    }
    else if (NowJ1Go == 0){
      Joker1Godown();
    }
  }
};


function Joker1Goup(){
if ( (JokerS.position.y + G_RayonJ1) < (wall1.position.y - (G_Eppaiwall1 / 2))) {
  JokerS.translateY(G_SpeedJ1);
  }
  else {NowJ1Go = 0;}
};

function Joker1Godown(){
  if ( (JokerS.position.y - G_RayonJ1) > (wall2.position.y + (G_Eppaiwall2 / 2))) {
  JokerS.translateY(-G_SpeedJ1);
  }
  else {NowJ1Go = 1;}
};


function SpawnJ1() {
  JokerShieldOn = 1;
  JokerS.position.x = G_J1_needX;
}

function J1Off(){
  JokerShieldOn = 0;
  JokerS.position.x = G_J1_initX;
}

function Bar1Shield() {
    shield1On = 1;
    shield1.position.x = -50;
    shield1.position.y = 0;


};

function Bar2Shield() {
    shield2On = 1;
    shield2.position.x = G_shield2Need;
    shield2.position.y = 0;

};
