var MedocOn = 0;
var NowCHGo = 1;
var EndRecherche = 0;
var  TryMedoc = 0;



function MedocMovement() {

if (MedocOn == 1) {
    if (NowCHGo == 1)
    {
      MedocGoup();
    }
    else if (NowCHGo == 0){
      MedocGodown();
    }
  }
};


function MedocGoup(){
if ( (medoc.position.y + G_RayonCH) < (wall1.position.y - (G_Eppaiwall1 / 2))) {
  medoc.translateY(G_SpeedCH);
  }
  else {NowCHGo = 0;}
};

function MedocGodown(){
  if ( (medoc.position.y - G_RayonCH) > (wall2.position.y + (G_Eppaiwall2 / 2))) {
  medoc.translateY(-G_SpeedCH);
  }
  else {NowCHGo = 1;}
};


function SpawnMedoc() {
  if ((HitRecherche >= G_RechercheNeed) && (EndRecherche == 0))
  {
  EndRecherche = 1;
  MedocOn = 1;
  medoc.position.x = G_CH_needX;
  medoc.position.y = G_CH_needY;


  J1Off();
}
};

function MedocOff(){
  MedocOn = 0;
  medoc.position.x = G_CH_initX;
};

function EndConfined(){

  if (cheatInvincible == 1) {
    invincible()
  }
    safe.position.x = G_SAFE_initX;
    wallS.position.x = G_SAFEwall_initX;
    stayhome = 0;
    EndRecherche = 0;
    HitRecherche = 0;
    MedocOff();

};
