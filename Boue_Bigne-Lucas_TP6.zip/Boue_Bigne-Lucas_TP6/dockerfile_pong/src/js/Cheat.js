var cheatInvincible = 0;
var shield1On = 0;
var shield2On = 0;


function levelup() {
  if (G_difficultyIA != 3){
    G_difficultyIA += 1;
  }
};

function leveldown() {
  if (G_difficultyIA != 1){
    G_difficultyIA -= 1;
  }
};

function killLife() {
  switch (G_CurrentLifeBar2) {
    case 3:
      sphere.position.x = G_goal2_initX;
      break;
    case 2:
      sphere.position.x = G_goal2B_initX;
      break;
    case 1:
      sphere.position.x = G_goal2C_initX;
      break;
      }
};


function killEnnemi() {
  G_CurrentLifeBar2 = 0;
  ResetBall();
};

function invincible() {
  if (cheatInvincible == 0) {
    wall3.position.x = G_wall3_needX;
    cheatInvincible = 1;
  }
  else if (cheatInvincible == 1){
    wall3.position.x = G_wall3_initX;
    cheatInvincible = 0;
  }
};

function Pushshield1() {
  if (shield1On == 0) {
    shield1.position.x = G_shield1Need;
    shield1.position.y = 0;
    shield1On = 1;
  }
  else if (shield1On == 1){
    shield1.position.x = G_shield1_initX;
    shield1On = 0;
  }
};

  function Pushshield2() {
    if (shield2On == 0) {
      shield2.position.x = G_shield2Need;
      shield2.position.y = 0;
      shield2On = 1;
    }
    else if (shield2On == 1){
      shield2.position.x = G_shield2_initX;
      shield2On = 0;
    }

};


function AddJ1() {
  SpawnJ1();
}

function AddCorona(){
  SpawnCorona();
}
