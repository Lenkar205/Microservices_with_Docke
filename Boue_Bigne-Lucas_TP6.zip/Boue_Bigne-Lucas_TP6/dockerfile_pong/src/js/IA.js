var bar2Cure = 0;

var NowShield1Go = 1; //1 up, 0 down
var NowShield2Go = 1;

function  IA() {

LvlEnnemi();
Hackbar2();
Shield1Movement();
Shield2Movement();
JokerShieldMovement();
CoronaMovement();
MedocMovement();

if (G_bar2Hack == 0)
{
  if (bar2.position.y < sphere.position.y){
    EnnemiGoUp();
  }
  else if (bar2.position.y > sphere.position.y){
    EnnemiGoDown();
  }
}
  else if (G_bar2Hack == 1){
    if (bar2.position.y < sphere.position.y){
      EnnemiGoDown();
    }
    else if (bar2.position.y > sphere.position.y){
      EnnemiGoUp();
    }

    bar2Cure += 1;
    if (bar2Cure == G_bar2TimeCure ){
      G_bar2Hack = 0;
      bar2Cure = 0;
    }

  }

};


function Hackbar2() {
  switch (G_difficultyIA) {
  case 1:
    if (TotalHit == (G_HitHackLvl1 * NbHack)) {
      G_bar2Hack = 1;
      NbHack = NbHack + 1;
    }
    break;
  case 2:
      if (TotalHit == (G_HitHackLvl2 * NbHack)) {
        G_bar2Hack = 1;
        NbHack = NbHack + 1;
      }
      break;
  case 3:
      if (TotalHit == (G_HitHackLvl3 * NbHack)) {
        G_bar2Hack = 1;
        NbHack = NbHack + 1;
        }
      break;
}
};




function Shield1Movement() {

if (shield1On == 1) {
    if (NowShield1Go == 1)
    {
      Shield1Goup();
    }
    else if (NowShield1Go == 0){
      Shield1Godown();
    }
  }
};

function Shield2Movement() {

if (shield2On == 1) {
    if (NowShield2Go == 1)
    {
      Shield2Goup();
    }
    else if (NowShield2Go == 0){
      Shield2Godown();
    }
  }
};


function Shield1Goup(){
if ( (shield1.position.y + Midshield) < (wall1.position.y - (G_Eppaiwall1 / 2))) {
  shield1.translateY(G_SpeedShield);
  }
  else {NowShield1Go = 0;}
};

function Shield1Godown(){
  if ( (shield1.position.y - Midshield) > (wall2.position.y + (G_Eppaiwall2 / 2))) {
  shield1.translateY(-G_SpeedShield);
  }
  else {NowShield1Go = 1;}
};

function Shield2Goup(){
  if ( (shield2.position.y + Midshield) < (wall1.position.y - (G_Eppaiwall1 / 2))) {
    shield2.translateY(G_SpeedShield);
    }
    else {NowShield2Go = 0;}
};

function Shield2Godown(){
  if ( (shield2.position.y - Midshield) > (wall2.position.y + (G_Eppaiwall2 / 2))) {
  shield2.translateY(-G_SpeedShield);
  }
  else {NowShield2Go = 1;}
};

function LvlEnnemi(){
  switch (G_difficultyIA) {
    case 1:
    Draw1();
      break;
    case 2:
      Draw2();
      break;
    case 3:
      Draw3();
      break;

  }
}

function Draw1(){
  DC.position.x = G_D_C;
  DD.position.x = G_D_D;

  DA.position.x = G_DrawingRemove;
  DB.position.x = G_DrawingRemove;
  DE.position.x = G_DrawingRemove;
  DF.position.x = G_DrawingRemove;
  DG.position.x = G_DrawingRemove;
}

function Draw2(){
  DC.position.x = G_D_C;
  DE.position.x = G_D_E;
  DG.position.x = G_D_G;
  DB.position.x = G_D_B;
  DF.position.x = G_D_F;

  DA.position.x = G_DrawingRemove;
  DD.position.x = G_DrawingRemove;
}

function Draw3(){
  DC.position.x = G_D_C;
  DE.position.x = G_D_E;
  DG.position.x = G_D_G;
  DD.position.x = G_D_D;
  DF.position.x = G_D_F;

  DA.position.x = G_DrawingRemove;
  DB.position.x = G_DrawingRemove;
}
