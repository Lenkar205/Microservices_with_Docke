var ActualSpeed = -G_vitesseball;
var MouvementBallY = G_ballY;
var HitCombo = 0;
var TotalHit = 0;
var HitRecherche = 0;
var NbHack = 1;
var possession = 0; //1 player 2 ennemi
var stayhome = 0;

var bar1TimeAFK = 0;
var bar2TimeAFK = 0;

var Midbar1 = G_Taillebar1/2;
var Midbar2 = G_Taillebar2/2;
var Fragbar1 = G_Taillebar1/3;
var Fragbar2 = G_Taillebar2/3;

var Midshield = G_Tailleshield/2;

function PlayerGoUp() {

  if (((bar1.position.y + (G_Taillebar1 / 2)) < (wall1.position.y - (G_Eppaiwall1 / 2))) && stayhome == 0) {
    bar1.translateY(G_Bar1_Speed);
    bar1.translateY(G_Bar1_Speed);
    bar1.translateY(G_Bar1_Speed);
    G_Bar1_Inertie = 1;
    bar1TimeAFK = 0;

  }
};


function PlayerGoDown() {

  if (((bar1.position.y - (G_Taillebar1 / 2)) > (wall2.position.y + (G_Eppaiwall2 / 2))) && stayhome == 0) {
    bar1.translateY(-G_Bar1_Speed);
    bar1.translateY(-G_Bar1_Speed);
    bar1.translateY(-G_Bar1_Speed);
    G_Bar1_Inertie = 2;
    bar1TimeAFK = 0;

  }
};


function EnnemiGoUp() {

  if ((bar2.position.y + (G_Taillebar2 / 2)) < (wall1.position.y - (G_Eppaiwall1 / 2))) {
    bar2.translateY(G_Bar2_Speed);
    bar2.translateY(G_Bar2_Speed);
    G_Bar2_Inertie = 1;
    bar2TimeAFK = 0;
  }
};


function EnnemiGoDown() {

  if ((bar2.position.y - (G_Taillebar2 / 2)) > (wall2.position.y + (G_Eppaiwall2 / 2))) {
    bar2.translateY(-G_Bar2_Speed);
    bar2.translateY(-G_Bar2_Speed);
    G_Bar2_Inertie = 2;
    bar2TimeAFK = 0;
  }
};


function BallMovement() {
  sphere.translateX(ActualSpeed);
  sphere.translateY(MouvementBallY);
};


function rebond() {

//****___Rebond sur bar1_________*************
//***-----------------------------------------vérification de l'axe y------------------------------****************----------vérification de l'axe x---------------------------
  if ( ((sphere.position.y >= bar1.position.y - Midbar1) && (sphere.position.y <= bar1.position.y + Midbar1)) &&  ((sphere.position.x <= bar1.position.x + 0.1) && (sphere.position.x >= bar1.position.x - 0.1))) {

    switch (G_Bar1_Inertie) {
    case 0:
      //pas d'effet
      NoEffectBar1();
      break;
    case 1:
      //effet vers le haut
      UpEffectBar1();
      break;
    case 2:
      //effet vers le bas
      DownEffectBar1();
      break;
  }

      sphere.material.color.setHex( G_Colorbar1 );
      ActualSpeed = -ActualSpeed;

      HitCombo += 1;
      TotalHit += 1;
      possession = 1;

}


//****___Rebond sur bar2_________*************
//***-----------------------------------------vérification de l'axe y------------------------------****************----------vérification de l'axe x---------------------------
  if ( ((sphere.position.y >= bar2.position.y - Midbar2) && (sphere.position.y <= bar2.position.y + Midbar2)) &&  ((sphere.position.x <= bar2.position.x + 0.5) && (sphere.position.x >= bar2.position.x - 0.5))) {

    switch (G_Bar2_Inertie) {
    case 0:
      //pas d'effet
      NoEffectBar2();
      break;
    case 1:
      //effet vers le haut
      UpEffectBar2();
      break;
    case 2:
      //effet vers le bas
      DownEffectBar2();
      break;
    }

    	sphere.material.color.setHex( G_Colorbar2 );
      HitCombo += 1;
      TotalHit += 1;
      ActualSpeed = -ActualSpeed;
      possession = 2;



}

//****___Rebond sur wall1_________*************
if (sphere.position.y >= (wall1.position.y - G_Rayonball))
{
	MouvementBallY = -MouvementBallY;
}

//****___Rebond sur wall2_________*************
if (sphere.position.y <= wall2.position.y + G_Rayonball)
{
	MouvementBallY = -MouvementBallY;
}

//invincible wall
//****___Rebond sur wall3_________*************

if ( sphere.position.x <= (wall3.position.x + G_Rayonball))
{
  sphere.material.color.setHex( G_Colorbar1 );
  ActualSpeed = -ActualSpeed;
  possession = 1;

  if (TryMedoc == 1) {
  HitRecherche = HitRecherche + 1;
}
}

//joker
//****___Rebond sur J1_________*************
if (JokerShieldOn == 1) {
  if ((sphere.position.x <= (JokerS.position.x + G_RayonJ1)) && (sphere.position.x >= (JokerS.position.x - G_RayonJ1)) && (sphere.position.y <= (JokerS.position.y + G_RayonJ1)) && (sphere.position.y >= (JokerS.position.y - G_RayonJ1)))
    {
        GiveShield();
        J1Off();
    }
}

//joker
//****___Rebond sur Coronavirus_________*************
if (CoronaOn == 1) {
  if ((sphere.position.x <= (coronavirus.position.x + G_RayonCO)) && (sphere.position.x >= (coronavirus.position.x - G_RayonCO)) && (sphere.position.y <= (coronavirus.position.y + G_RayonCO)) && (sphere.position.y >= (coronavirus.position.y - G_RayonCO)))
    {
        BeginConfined();
    }
}

//joker
//****___Rebond sur Medoc_________*************
if (MedocOn == 1) {
  if ((sphere.position.x <= (medoc.position.x + G_RayonCH)) && (sphere.position.x >= (medoc.position.x - G_RayonCH)) && (sphere.position.y <= (medoc.position.y + G_RayonCH)) && (sphere.position.y >= (medoc.position.y - G_RayonCH)))
    {
        EndConfined();
    }
}


//joker
//****___Rebond sur shield1_________*************
if (shield1On == 1) {
if ((sphere.position.x <= (shield1.position.x + G_Rayonball)) && ((sphere.position.y >= shield1.position.y - Midshield) && (sphere.position.y <= shield1.position.y + Midshield)) )
{
  HitCombo += 1;
  TotalHit += 1;
  ActualSpeed = -ActualSpeed;
  Pushshield1();
  possession = 1
}
}

//joker
//****___Rebond sur shield2_________*************
if (shield2On == 1) {
if ( (sphere.position.x >= (shield2.position.x - G_Rayonball)) && ((sphere.position.y >= shield2.position.y - Midshield) && (sphere.position.y <= shield2.position.y + Midshield)) )
{
  HitCombo += 1;
  TotalHit += 1;
  ActualSpeed = -ActualSpeed;
  Pushshield2();
  possession = 2;
}
}

//****___Rebond sur goal1_________*************
if (sphere.position.x <= goal1.position.x + G_Rayonball) {
    turn = 1;
    goal1.position.x = -200
    G_CurrentLifeBar1 = G_CurrentLifeBar1 - 1;
    ResetBall(1);
}

//goal1B
if (sphere.position.x <= goal1B.position.x + G_Rayonball) {
    goal1B.position.x = -204
    G_CurrentLifeBar1 = G_CurrentLifeBar1 - 1;
    ResetBall(1);
}

//goal1C
if (sphere.position.x <= goal1C.position.x + G_Rayonball) {
    goal1C.position.x = -208
    G_CurrentLifeBar1 = G_CurrentLifeBar1 - 1;
    ResetBall(1);
}

//****___Rebond sur goal2_________*************
if (sphere.position.x >= goal2.position.x - G_Rayonball) {
    goal2.position.x = 212
    G_CurrentLifeBar2 = G_CurrentLifeBar2 - 1;
    ResetBall(2);
}

//goal2B
if (sphere.position.x >= goal2B.position.x - G_Rayonball) {
    goal2B.position.x = 216
    G_CurrentLifeBar2 = G_CurrentLifeBar2 - 1;
    ResetBall(2);
}

//goal2C
if (sphere.position.x >= goal2C.position.x - G_Rayonball) {
    goal2C.position.x = 220
    G_CurrentLifeBar2 = G_CurrentLifeBar2 - 1;
    ResetBall(2);
}

//Safe wal
if (sphere.position.x >= wallS.position.x - G_Rayonball) {
  HitRecherche = HitRecherche + 1;
  ActualSpeed = -ActualSpeed;
}

EndInnertiebar1();
EndInnertiebar2();
AddJoker();
SpawnMedoc();
SpeedVariation();

};

function ResetBall(turn) {

  sphere.material.color.setHex( G_Colorball );
  sphere.position.x = 0;
  sphere.position.y = 0;
  bar1.position.y = 0;
  bar2.position.y = 0;
  HitCombo = 0;
  TotalHit = 0;
  NbHack = 1;
  G_bar2Hack = 0;
  G_Bar1_Inertie = 0;
  G_Bar2_Inertie = 0;
  possession = 0;

  if (turn == 1) {  ActualSpeed = -G_vitesseball; }
  else if (turn == 2){ ActualSpeed = G_vitesseball;}
  MouvementBallY = G_ballY;

  ResetMatch();
  J1Off();
  CoronaOff();

};

function ResetMatch() {
  //défaite joueuer
  if (G_CurrentLifeBar1 == 0) {
    Placement();
    G_CurrentLifeBar1 = 3;
    G_CurrentLifeBar2 = 3;
    shield1On = 0;
    shield2On = 0;

  }
  //victoire joueuer
  else if (G_CurrentLifeBar2 == 0)
  {
    Placement();
    G_CurrentLifeBar1 = 3;
    G_CurrentLifeBar2 = 3;
    shield1On = 0;
    shield2On = 0;

    if (G_difficultyIA != 3){
      G_difficultyIA += 1;

    }
  }
};

function SpeedVariation() {

if (HitCombo >= G_BallSpeedHit) {
  if (ActualSpeed > 0)
  {
    if (ActualSpeed < G_MaxSpeedBall) {

      ActualSpeed  = ActualSpeed + G_BallSpeedStep;
      HitCombo = 0;
    }
  }
  else {
    if (ActualSpeed > -G_MaxSpeedBall) {
      ActualSpeed = ActualSpeed - G_BallSpeedStep;
      HitCombo = 0;
    }
  }
}
};



function AddJoker() {
  if (TotalHit == G_HitSpawnJ1)
  {
    SpawnJ1();
  }

  if (TotalHit == G_HitSpawnCO)
  {
    SpawnCorona();
  }

};
