// bar palyer
//---------Bar1-------------
var G_Taillebar1 = 10;
var G_Colorbar1 = 0xff3333;
var G_Bar1_initX = -60; //position sur l'axe x de la bar1
var G_Bar1_Speed = 0.4;
var G_Bar1_Inertie = 0; //0-> non, 1-> up, 2-> down
var G_CurrentLifeBar1 = 3;
var G_TimeNoInnertibar1 = 10;
//----------------------------

//------------rebond--------
var G_Angle1 = 0.2
var G_Angle2 = 0.4
var G_Angle3 = 0.6
//--------------------------

//bar ennemi
//---------Bar2-------------
var G_Taillebar2 = 10;
var G_Colorbar2 = 0x0000ff;
var G_Bar2_initX = 60; //position sur l'axe xcde la bar1
var G_Bar2_Speed = 0.25;
var G_bar2Hack = 0;
var G_bar2TimeCure = 80;
var G_Bar2_Inertie = 0 //0-> non, 1-> up, 2-> down
var G_CurrentLifeBar2 = 3;
var G_TimeNoInnertibar2 = 10;
//----------------------------

//blastzone player
//------Goal1-------------
var G_Taillegoal1 = 60;
var G_Colorgoal1 = 0xF614FF;
var G_goal1_initX = -64;
var G_goal1B_initX = -68;
var G_goal1C_initX = -72;
//-----------------------

//blastzone ennemi
//------Goal2-------------
var G_Taillegoal2 = 60;
var G_Colorgoal2 = 0xF614FF;
var G_goal2_initX = 64;
var G_goal2B_initX = 68;
var G_goal2C_initX = 72;
//-----------------------

//wall up
//------Wall1-------------
var G_Taillewall1 = 150;
var G_Colorwall1 = 0xFF9B05;
var G_wall1_initY = 30;
var G_Eppaiwall1 = 1; //épaisseur mur
//-----------------------

//wall down
//------Wall2-------------
var G_Taillewall2 = 150;
var G_Colorwall2 = 0xFF9B05;
var G_wall2_initY = -30;
var G_Eppaiwall2 = 1;
//-----------------------

//joker
//-------Shield----------
var G_Tailleshield = 7;
var G_Colorshield = 0xD3D3D3;
var G_SpeedShield = 0.4;
var G_shield1_initX = -253;
var G_shield2_initX = 253;
var G_shield1Need = -50;
var G_shield2Need = 50
//-------------------------

//--------J1----------
var G_RayonJ1 = 2;
var G_ColorJ1 = 0xD3D3D3;
var G_SpeedJ1 = 0.4;
var G_J1_initX = -236;
var G_J1_needX = 0;
var G_HitSpawnJ1 = 7;
//-------------------

//---------Corona---------
var G_RayonCO = 3;
var G_ColorCO = 0xF0E68C;
var G_SpeedCO = 0.8;
var G_CO_initX = 236;
var G_CO_needX = -15;
var G_HitSpawnCO = 14;
//--------------------------

//------Choloroquine-------
var G_RayonCH = 2;
var G_ColorCH = 0x00FF00;
var G_SpeedCH = 0.5;
var G_CH_initX = 241;
var G_CH_needX = -35;
var G_CH_needY = -20;
var G_HitSpawnCH = 4;
var G_RechercheNeed = 5;
//------------------

//---------SafetyArea----------
var G_TailleSafe = G_Taillebar1 + 4;
var G_ColorSAFE = 0x00FF00;
var G_SAFE_initX = 241;
var G_SAFE_needX = -60;
var G_SAFE_needY = 0;
//-----------------------------

//---------safeWall-----------
var G_TailleSafewall = G_Taillegoal2;
var G_SAFEwall_initX = 249;
var G_SAFEwall_needX = 0;

//incible mode
//-----------wall3--------

var G_wall3_initX = -250;
var G_wall3_needX = -57
var G_Colorwall3 = 0xffffff;
var G_Taillewall3 = 60;
//-------------------------

//Sphere
//-------Ball----------
var G_Rayonball = 1;
var G_Colorball = 0xffffff;
var G_vitesseball = 0.6;
var G_ballY = 0;
//------------------------

//Settings
//------------Game----------
var G_BallSpeedHit = 2 ;//nombre de hit nécessaire pour accélerer la balle
var G_MaxSpeedBall = 1.2;
var G_BallSpeedStep = 0.2; //accélération de la balle
var G_difficultyIA = 1;
var G_HitHackLvl1 = 3;
var G_HitHackLvl2 = 5;
var G_HitHackLvl3 = 7;
//--------------------------

//--------Drawing-------
var G_Taille_police = 2;
var G_Colorpolice = G_Colorbar2;
var G_D_A = 70;
var G_D_B = 70;
var G_D_C = 72;
var G_D_D = 72;
var G_D_E = 71;
var G_D_F = 71;
var G_D_G = 71;

var G_DrawingRemove = 330;
//--------------

//------Scene-------------
var G_ReculCamera = 50; //recul de base de la main cam
//-------------------------
