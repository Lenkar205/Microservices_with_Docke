
function NoEffectBar1() {

if ( sphere.position.y >= (bar1.position.y + Fragbar1)) //tout en haut angle 3
  { MouvementBallY = G_Angle3}
if ( (sphere.position.y < (bar1.position.y + Fragbar1)) && (sphere.position.y > (bar1.position.y + 1))) // haut angle 2
  { MouvementBallY = G_Angle2}
if ( (sphere.position.y <= (bar1.position.y + 1)) && (sphere.position.y >= (bar1.position.y - 1))) //angle 1
  { MouvementBallY = MouvementBallY}
if ( (sphere.position.y > (bar1.position.y - Fragbar1)) && (sphere.position.y < (bar1.position.y - 1))) //bas angle 2
{ MouvementBallY = -G_Angle2}
if ( sphere.position.y <= (bar1.position.y - Fragbar1)) //tout en bas angle 3
  { MouvementBallY = -G_Angle3}

};

function UpEffectBar1() {

if ( sphere.position.y >= (bar1.position.y + Fragbar1)) //tout en haut angle 3
  { MouvementBallY = G_Angle3}
if ( (sphere.position.y < (bar1.position.y + Fragbar1)) && (sphere.position.y > (bar1.position.y + 1))) // haut angle 2
  { MouvementBallY = G_Angle2}
if ( (sphere.position.y <= (bar1.position.y + 1)) && (sphere.position.y >= (bar1.position.y - 1))) //angle 1
  { MouvementBallY = G_Angle1}
if ( (sphere.position.y > (bar1.position.y - Fragbar1)) && (sphere.position.y < (bar1.position.y - 1))) //bas angle 2
{ MouvementBallY = G_Angle2}
if ( sphere.position.y <= (bar1.position.y - Fragbar1)) //tout en bas angle 3
  { MouvementBallY = G_Angle3}

};

function DownEffectBar1() {

if ( sphere.position.y >= (bar1.position.y + Fragbar1)) //tout en haut angle 3
  { MouvementBallY = -G_Angle3}
if ( (sphere.position.y < (bar1.position.y + Fragbar1)) && (sphere.position.y > (bar1.position.y + 1))) // haut angle 2
  { MouvementBallY = -G_Angle2}
if ( (sphere.position.y <= (bar1.position.y + 1)) && (sphere.position.y >= (bar1.position.y - 1))) //angle 1
  { MouvementBallY = -G_Angle1}
if ( (sphere.position.y > (bar1.position.y - Fragbar1)) && (sphere.position.y < (bar1.position.y - 1))) //bas angle 2
{ MouvementBallY = -G_Angle2}
if ( sphere.position.y <= (bar1.position.y - Fragbar1)) //tout en bas angle 3
  { MouvementBallY = -G_Angle3}

};

function NoEffectBar2() {

if ( sphere.position.y >= (bar2.position.y + Fragbar2)) //tout en haut angle 3
  { MouvementBallY = G_Angle3}
if ( (sphere.position.y < (bar2.position.y + Fragbar2)) && (sphere.position.y > (bar2.position.y + 1))) // haut angle 2
  { MouvementBallY = G_Angle2}
if ( (sphere.position.y <= (bar2.position.y + 1)) && (sphere.position.y >= (bar2.position.y - 1))) //angle 1
  { MouvementBallY = MouvementBallY}
if ( (sphere.position.y > (bar2.position.y - Fragbar2)) && (sphere.position.y < (bar2.position.y - 1))) //bas angle 2
{ MouvementBallY = -G_Angle2}
if ( sphere.position.y <= (bar2.position.y - Fragbar2)) //tout en bas angle 3
  { MouvementBallY = -G_Angle3}

};

function UpEffectBar2() {

if ( sphere.position.y >= (bar2.position.y + Fragbar2)) //tout en haut angle 3
  { MouvementBallY = G_Angle3}
if ( (sphere.position.y < (bar2.position.y + Fragbar2)) && (sphere.position.y > (bar2.position.y + 1))) // haut angle 2
  { MouvementBallY = G_Angle2}
if ( (sphere.position.y <= (bar2.position.y + 1)) && (sphere.position.y >= (bar2.position.y - 1))) //angle 1
  { MouvementBallY = G_Angle1}
if ( (sphere.position.y > (bar2.position.y - Fragbar2)) && (sphere.position.y < (bar2.position.y - 1))) //bas angle 2
{ MouvementBallY = G_Angle2}
if ( sphere.position.y <= (bar2.position.y - Fragbar2)) //tout en bas angle 3
  { MouvementBallY = G_Angle3}

};

function DownEffectBar2() {

if ( sphere.position.y >= (bar2.position.y + Fragbar2)) //tout en haut angle 3
  { MouvementBallY = -G_Angle3}
if ( (sphere.position.y < (bar2.position.y + Fragbar2)) && (sphere.position.y > (bar2.position.y + 1))) // haut angle 2
  { MouvementBallY = -G_Angle2}
if ( (sphere.position.y <= (bar2.position.y + 1)) && (sphere.position.y >= (bar2.position.y - 1))) //angle 1
  { MouvementBallY = -G_Angle1}
if ( (sphere.position.y > (bar2.position.y - Fragbar2)) && (sphere.position.y < (bar2.position.y - 1))) //bas angle 2
{ MouvementBallY = -G_Angle2}
if ( sphere.position.y <= (bar2.position.y - Fragbar2)) //tout en bas angle 3
  { MouvementBallY = -G_Angle3}

};


function EndInnertiebar1() {
  bar1TimeAFK += 1

  if (bar1TimeAFK >= G_TimeNoInnertibar1){
    G_Bar1_Inertie = 0;
  }
};

function EndInnertiebar2() {
  bar2TimeAFK += 1

  if (bar1TimeAFK >= G_TimeNoInnertibar2){
    G_Bar2_Inertie = 0;
      bar2TimeAFK = 0
  }
};
