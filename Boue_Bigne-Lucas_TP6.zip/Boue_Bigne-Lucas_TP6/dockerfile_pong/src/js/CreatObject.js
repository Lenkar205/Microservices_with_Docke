

function Placement() {

  //place les objtes de de la scéne a leur position initial
  bar1.position.x = G_Bar1_initX;
  bar1.position.y = 0;
  bar1.position.z = 0;

  bar2.position.x = G_Bar2_initX;
  bar2.position.y = 0;
  bar2.position.z = 0;

  goal1.position.x = G_goal1_initX;
  goal1.position.y = 0;
  goal1.position.z = 0;

  goal1B.position.x = G_goal1B_initX;
  goal1B.position.y = 0;
  goal1B.position.z = 0;

  goal1C.position.x = G_goal1C_initX;
  goal1C.position.y = 0;
  goal1C.position.z = 0;

  goal2.position.x = G_goal2_initX;
  goal2.position.y = 0;
  goal2.position.z = 0;

  goal2B.position.x = G_goal2B_initX;
  goal2B.position.y = 0;
  goal2B.position.z = 0;

  goal2C.position.x = G_goal2C_initX;
  goal2C.position.y = 0;
  goal2C.position.z = 0;

  camera.position.x = 0;
  camera.position.y = 0;
  camera.position.z = G_ReculCamera;

  wall1.position.x = 0;
  wall1.position.y = G_wall1_initY;
  wall1.position.z = 0;

  wall2.position.x = 0;
  wall2.position.y = G_wall2_initY;
  wall2.position.z = 0;

  wall3.position.x = G_wall3_initX;
  wall3.position.y = 0;
  wall3.position.z = 0;

  sphere.position.x = 0;
  sphere.position.y = 0;
  sphere.position.z = 0;

  shield1.position.x = G_shield1_initX;
  shield1.position.y = 0;
  shield1.position.z = 0;

  shield2.position.x = G_shield2_initX;
  shield2.position.y = 0;
  shield2.position.z = 0;

  JokerS.position.x = G_J1_initX;
  JokerS.position.y = 0;
  JokerS.position.z = 0;

  coronavirus.position.x = G_J1_initX;
  coronavirus.position.y = 0;
  coronavirus.position.z = 0;

  medoc.position.x = G_CH_initX;
  medoc.position.y = 0;
  medoc.position.z = 0;

  safe.position.x = G_SAFE_initX;
  safe.position.y = 0;
  safe.position.z = 0;

  wallS.position.x = G_SAFEwall_initX;
  wallS.position.y = 0;
  wallS.position.z = 0;

  DA.position.x = G_D_A;
  DB.position.x = G_D_B;
  DC.position.x = G_D_C;
  DD.position.x = G_D_D;
  DE.position.x = G_D_E;
  DF.position.x = G_D_F;
  DG.position.x = G_D_G;

  DA.position.y = -34;
  DB.position.y = -36;
  DC.position.y = -34;
  DD.position.y = -36;
  DE.position.y = -33;
  DF.position.y = -37;
  DG.position.y = -35;



};
