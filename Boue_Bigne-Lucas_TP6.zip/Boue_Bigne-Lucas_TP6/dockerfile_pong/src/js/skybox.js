/*
		var skyBoxGeometry =new THREE.CubeGeometry (100 , 100 , 100);
		var skyBoxMaterials = [
			new THREE.MeshBasicMaterial( { map: new THREE.TextureLoader().load('src/medias/image/Rock/cocoa_ft.jpg'), side : THREE.Doubleside } ),
			new THREE.MeshBasicMaterial( { map: new THREE.TextureLoader().load('src/medias/image/Rock/cocoa_bk.jpg'), side : THREE.Doubleside } ),
			new THREE.MeshBasicMaterial( { map: new THREE.TextureLoader().load('src/medias/image/Rock/cocoa_up.jpg'), side : THREE.Doubleside } ),
			new THREE.MeshBasicMaterial( { map: new THREE.TextureLoader().load('src/medias/image/Rock/cocoa_dn.jpg'), side : THREE.Doubleside } ),
			new THREE.MeshBasicMaterial( { map: new THREE.TextureLoader().load('src/medias/image/Rock/cocoa_rt.jpg'), side : THREE.Doubleside } ),
			new THREE.MeshBasicMaterial( { map: new THREE.TextureLoader().load('src/medias/image/Rock/cocoa_lf.jpg'), side : THREE.Doubleside } )
		];
		var skyBoxMaterial = new THREE.MeshBasicMaterial(skyBoxMaterials);
		var skyBox = new THREE.Mesh ( skyBoxGeometry, skyBoxMaterial );
		scene.add( skyBox);
*/
