var CoronaOn = 0;
var NowCOGo = 1;



function CoronaMovement() {

if (CoronaOn == 1) {
    if (NowCOGo == 1)
    {
      CoronaGoup();
    }
    else if (NowCOGo == 0){
      CoronaGodown();
    }
  }
};


function CoronaGoup(){
if ( (coronavirus.position.y + G_RayonCO) < (wall1.position.y - (G_Eppaiwall1 / 2))) {
  coronavirus.translateY(G_SpeedCO);
  }
  else {NowCOGo = 0;}
};

function CoronaGodown(){
  if ( (coronavirus.position.y - G_RayonCO) > (wall2.position.y + (G_Eppaiwall2 / 2))) {
  coronavirus.translateY(-G_SpeedCO);
  }
  else {NowCOGo = 1;}
};


function SpawnCorona() {
  CoronaOn = 1;
  coronavirus.position.x = G_CO_needX;
  J1Off();
}

function CoronaOff(){
  CoronaOn = 0;
  coronavirus.position.x = G_CO_initX;
}


function BeginConfined(){
  HitRecherche = 0;
  PlacementConffinement();
  CoronaOff();
  SpawnMedoc();
  sphere.position.x = -40;
  sphere.position.y = 0;
  MouvementBallY = 0;
  TryMedoc = 1;
  shield1.position.x = G_shield1_initX;
  shield1On = 0;
  shield2.position.x = G_shield2_initX;
  shield2On = 0;

}

function PlacementConffinement() {
  if (cheatInvincible == 0) {
    invincible()
  }
    safe.position.x = G_SAFE_needX;
    safe.position.y = G_SAFE_needY;
    bar1.position.x = G_SAFE_needX;
    bar1.position.y = G_SAFE_needY;
    wallS.position.x = G_SAFEwall_needX;
    stayhome = 1;

}
